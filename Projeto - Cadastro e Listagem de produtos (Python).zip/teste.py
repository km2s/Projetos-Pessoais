import tkinter as tk
from tkinter import ttk, messagebox

class Product:
    def __init__(self, name, description, value, available):
        self.name = name
        self.description = description
        self.value = value
        self.available = available

class ProductApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Cadastro de Produtos")
        self.products = []

        # Frame for the form
        self.form_frame = tk.Frame(root)
        self.form_frame.pack(pady=10)

        tk.Label(self.form_frame, text="Nome do produto:").grid(row=0, column=0, padx=5, pady=5)
        self.name_entry = tk.Entry(self.form_frame)
        self.name_entry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(self.form_frame, text="Descrição do produto:").grid(row=1, column=0, padx=5, pady=5)
        self.description_entry = tk.Entry(self.form_frame)
        self.description_entry.grid(row=1, column=1, padx=5, pady=5)

        tk.Label(self.form_frame, text="Valor do produto:").grid(row=2, column=0, padx=5, pady=5)
        self.value_entry = tk.Entry(self.form_frame)
        self.value_entry.grid(row=2, column=1, padx=5, pady=5)

        tk.Label(self.form_frame, text="Disponível para venda:").grid(row=3, column=0, padx=5, pady=5)
        self.available_var = tk.StringVar(value="sim")
        tk.Radiobutton(self.form_frame, text="Sim", variable=self.available_var, value="sim").grid(row=3, column=1, padx=5, pady=5, sticky=tk.W)
        tk.Radiobutton(self.form_frame, text="Não", variable=self.available_var, value="não").grid(row=3, column=2, padx=5, pady=5, sticky=tk.W)

        tk.Button(self.form_frame, text="Cadastrar", command=self.add_product).grid(row=4, columnspan=3, pady=10)

        # Frame for the product list
        self.list_frame = tk.Frame(root)
        self.list_frame.pack(pady=10)

        self.tree = ttk.Treeview(self.list_frame, columns=("name", "value"), show="headings")
        self.tree.heading("name", text="Nome")
        self.tree.heading("value", text="Valor")
        self.tree.pack()

        tk.Button(self.list_frame, text="Novo Produto", command=self.show_form).pack(pady=10)

    def add_product(self):
        name = self.name_entry.get()
        description = self.description_entry.get()
        value = self.value_entry.get()
        available = self.available_var.get()

        if name and description and value:
            try:
                value = float(value)
                product = Product(name, description, value, available)
                self.products.append(product)
                self.products.sort(key=lambda p: p.value)
                self.update_treeview()
                self.show_list()
            except ValueError:
                messagebox.showerror("Erro", "O valor do produto deve ser um número.")
        else:
            messagebox.showerror("Erro", "Todos os campos são obrigatórios.")

    def update_treeview(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for product in self.products:
            self.tree.insert("", "end", values=(product.name, product.value))

    def show_form(self):
        self.form_frame.pack(pady=10)
        self.list_frame.pack_forget()

    def show_list(self):
        self.form_frame.pack_forget()
        self.list_frame.pack(pady=10)

if __name__ == "__main__":
    root = tk.Tk()
    app = ProductApp(root)
    root.mainloop()
